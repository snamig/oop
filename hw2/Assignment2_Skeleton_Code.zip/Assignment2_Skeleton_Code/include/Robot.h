//--- 2021-2022 Summer Object Oriented Programing Assignment 2 ---//
//--------------------------//
//---Name & Surname:
//---Student Number:
//--------------------------//
#include <iostream>
#ifndef _H
#define _H
using namespace std;
class Robot {
	private:
		int unqID;
		string RobotName;
		string RobotType;
		float speed; 
		int durability; 
		int manufactureCost; 
		float maintenanceCost;
		bool canMove;
	
	public:
		           
}; 

class Explorer{
	private:
		float totalExploredArea;
		int totalNumberOfSeleniumArea;
		float exploredArea;
		bool detectedSelenium;
		
		
	public:
		
};

class Miner{
	private:
		int totalGatheredSelenium;
		int gatheredSelenium;

		
	public:
		


};


#endif