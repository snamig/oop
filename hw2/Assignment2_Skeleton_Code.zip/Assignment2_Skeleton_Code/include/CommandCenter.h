#include <iostream>
#include "Robot.h"
using namespace std;
class Crew{
	private:
		int maxExplorers;
		int maxMiners;
		int crewManufactureCost;
		float crewMaintenanceCost;
		int explorerCrewSize;
		int minerCrewSize;
		Explorer **ExplorerCrew;
		Miner **MinerCrew;
		
	public:
};

class CommandCenter{
	private:
		int neededSelenium;
		float searchArea;
		int seleniumWorth;
		int turnCount;
		float totalCrewMaintenanceCost;
		float profit;
	public:


};



